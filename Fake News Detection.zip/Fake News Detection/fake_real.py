import os
import re
import string
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier

# File paths
mlp_model_path = 'mlp_model.pkl'
tfidf_vectorizer_path = 'tfidf_vectorizer.pkl'
dataset_path = 'fake_and_real_news.csv'

# Preprocessing function
def clean_text(text):
    text = text.lower()  # Convert to lowercase
    text = re.sub(r"\d+", "", text)  # Remove numbers
    text = text.translate(str.maketrans("", "", string.punctuation))  # Remove punctuation
    text = re.sub(r"\s+", " ", text).strip()  # Remove extra spaces
    return text

# Train model if files do not exist
if not os.path.exists(mlp_model_path) or not os.path.exists(tfidf_vectorizer_path):
    print("Training model as no pre-trained model was found...")
    df = pd.read_csv(dataset_path)
    df['Text'] = df['Text'].astype(str).apply(clean_text)
    X = df['Text']
    y = df['label']
    vectorizer = TfidfVectorizer(max_features=5000, stop_words='english')
    X_tfidf = vectorizer.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X_tfidf, y, test_size=0.2, random_state=42)
    mlp = MLPClassifier(hidden_layer_sizes=(100, 50), activation='relu', solver='adam', max_iter=300)
    mlp.fit(X_train, y_train)
    joblib.dump(mlp, mlp_model_path)
    joblib.dump(vectorizer, tfidf_vectorizer_path)
    print("Model training completed and saved.")
else:
    print("Loading existing model...")
    mlp = joblib.load(mlp_model_path)
    vectorizer = joblib.load(tfidf_vectorizer_path)

def predict_news():
    user_input = input("Enter the news article: ")
    cleaned_input = clean_text(user_input)
    input_tfidf = vectorizer.transform([cleaned_input])
    prediction = mlp.predict(input_tfidf)[0]
    print(f"The news is classified as: {prediction}")

predict_news()
